package OOP01.ExercAplicadoOOP;

// Interface que define as operações bancárias *Ainda não entendi totalmente o que é uma interface, mas vamos lá!*

public interface OperacoesBancarias {
    public void depositar(double valor);

    public void sacar(double valor);
}
